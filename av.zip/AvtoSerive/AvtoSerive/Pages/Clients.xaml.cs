﻿using AvtoSerive.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static AvtoSerive.MainWindow;

namespace AvtoSerive.Pages
{
    /// <summary>
    /// Логика взаимодействия для Clients.xaml
    /// </summary>
    public partial class Clients : Page
    {
        Frame Frame;
        private int start = 0;
        private int fullCount = 0;
        private int order = 0;
        private int iag = 0;
        private string fnd = string.Empty;
        private string Name = string.Empty;
        public Clients(Frame frame)
        {
            Frame = frame;
            InitializeComponent();

            Load();
        }

        public void Load()
        {
            try
            {
                List<Client> client = new List<Client>();
                var ag = helper.GetContext().Client.Where(Client => Client.LastName.Contains(fnd) || Client.FirstName.Contains(fnd) || Client.Patronymic.Contains(fnd) || Client.Phone.Contains(fnd) || Client.Email.Contains(fnd));
                if (iag > 0) ag = helper.GetContext().Client.Where(Client => (Client.LastName.Contains(fnd) || Client.FirstName.Contains(fnd) || Client.FirstName.Contains(fnd) || Client.Phone.Contains(fnd) || Client.Email.Contains(fnd)));
                client.Clear();
                foreach (Client clients in ag)
                {
                    clients.Name = clients.LastName + " " + clients.FirstName + " " + clients.Patronymic;
                    if (clients.PhotoPath == "")
                    {
                        clients.PhotoPath = "/Клиенты/1.jpg";
                        

                    }
                    else
                    {
                        clients.PhotoPath = @"\"+ clients.PhotoPath.Remove(0,1);
                    }


                }   
                if (order == 0) clientsGrid.ItemsSource = ag.OrderBy(Client => Client.ID).Skip(start * 10).Take(10).ToList();
                if (order == 1) clientsGrid.ItemsSource = ag.OrderBy(Client => Client.LastName).Skip(start * 10).Take(10).ToList();
                if (order == 2) clientsGrid.ItemsSource = ag.OrderByDescending(Client => Client.LastName).Skip(start * 10).Take(10).ToList();

                fullCount = ag.Count();

                int ost = fullCount % 10;
                int pag = (fullCount - ost) / 10;
                if (ost > 0) pag++;
                pagin.Children.Clear();
                for (int i = 0; i < pag; i++)
                {
                    Button myButton = new Button();
                    myButton.Height = 30;
                    myButton.Content = i + 1;
                    myButton.Width = 20;
                    myButton.HorizontalAlignment = HorizontalAlignment.Center;
                    myButton.Tag = i;
                    myButton.Click += new RoutedEventHandler(paginButto_Click);
                    pagin.Children.Add(myButton);
                }

                // fullCount = helper.GetContext().Agent.Count();
                full.Text = fullCount.ToString();
                turnButton();
            }
            catch
            {
                return;
            };

        }

        private void turnButton()
        {
            if (start == 0) { back.IsEnabled = false; }
            else { back.IsEnabled = true; };
            if ((start) * 10 + 10 >= fullCount) { forward.IsEnabled = false; }
            else { forward.IsEnabled = true; };
        }


        private void paginButto_Click(object sender, RoutedEventArgs e)
        {
            start = Convert.ToInt32(((Button)sender).Tag.ToString());
            Load();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            start--;
            Load();
        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            start++;
            Load();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            fnd = ((TextBox)sender).Text;
            Load();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox comboBox = (ComboBox)sender;
            ComboBoxItem selectedItem = (ComboBoxItem)comboBox.SelectedItem;
            order = Convert.ToInt32(selectedItem.Tag.ToString());
            Load();
        }

        private void Type_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void agentGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (clientsGrid.SelectedItems.Count > 0)
            {
                Client client = clientsGrid.SelectedItems[0] as Client;

                if (client != null)
                {
                    Frame.Content = new clientsEdit(client);
                }
            }
        }

        private void agentGrid_LoadingRow(object sender, DataGridRowEventArgs e)
        {

        }

        private void updateButton_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Content = new clientsEdit(null);
        }
    }
}
